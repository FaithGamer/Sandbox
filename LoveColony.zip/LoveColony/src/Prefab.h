#pragma once

#include "Sandbox\Sandbox.h"
using namespace Sandbox;

namespace Prefab
{
	Entity Colonist();
	Entity Wall();
}